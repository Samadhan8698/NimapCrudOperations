package com.data.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.data.Entity.Category;
import com.data.Entity.Product;
import com.data.repository.CategoryRepository;
import com.data.repository.ProductRepository;

@Service
public class PCService {

	@Autowired
	ProductRepository pr;
	
	@Autowired
	CategoryRepository cr;
	
	public String save(Product p) 
	{
		pr.save(p);
		return "product added successful";
	}
	
	public List<Product> findAllPR() 
	{
		return pr.findAll();
	}
	
	public Product findPR(int pid) 
	{
		return pr.findById(pid)  .orElse(null);
	}
	
	public String deleteById(int pid) {
		pr.deleteById(pid);
		return "1 Record deleted successfully..!";
	}
	
	public String updateProduct(int pid,Product p1) {
		
		Product p2=pr.findById(pid)  .orElse(null);
			
			if(p1!=null) {
				
				if(p1.getPname()!=null)
				{
					p2.setPname(p1.getPname());
				}
				if(p1.getPrice()!=0.0)
				{
					p2.setPrice(p1.getPrice());
				}
			}
			pr.save(p2);
			return "1 Record updated successfully"; 
		}

	
	public String save1(Category c) 
	{
		for(Product t:c.getProducts()) {
			t.setCat(c);
		}
		cr.save(c);
		return "Category added successful";
	}
	
	public List<Category> findAllCR() 
	{
		return cr.findAll();
	}
	
	public Category findCR(int cid) 
	{
		return cr.findById(cid)  .orElse(null);
	}
	
	public String deleteById1(int cid) {
		cr.deleteById(cid);
		return "category deleted successfully..!";
	}
	
	public String updateCategory(int cid,Category c1) {
		
		Category c2=cr.findById(cid)  .orElse(null);
			
			if(c1!=null) {
				
				if(c1.getCname()!=null)
				{
					c2.setCname(c1.getCname());
				}
			}
			cr.save(c2);
			return "1 Record updated successfully"; 
		}

}
