package com.data.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.data.Entity.Category;
import com.data.Entity.Product;
import com.data.Service.PCService;

@RestController
public class PCController {

	@Autowired
	PCService ps;

	
	@PostMapping("/savepro")
	public String save(@RequestBody Product p) {
		return ps.save(p);
	}
	
	@GetMapping("/findPR/{pid}")
	public Product findPR(@PathVariable("pid") int pid) {
		return ps.findPR(pid);    
	}
	
	@GetMapping("/findallPR")
	public List<Product> findAllPR() 
	{
		return ps.findAllPR();
	}
	
	@DeleteMapping("/deletePR/{id}")
	public String deleteById(@PathVariable("id") int pid) 
	{
		 return ps.deleteById(pid);
	}
	
	@PutMapping("/updatePR/{id}")
	public String updateProductData(@PathVariable("id") int pid, @RequestBody Product p1)
	{
		return ps.updateProduct(pid, p1);
	}
	
	//for category 
	
	@PostMapping("/saveCat")
	public String save(@RequestBody Category c) 
	{
		ps.save1(c);
		return "Category added successful";
	}
	
	@GetMapping("/findallCat1")
	public List<Category> findAllCR() 
	{
		return ps.findAllCR();
	}
	
	@GetMapping("/findCat1/{cid}")
	public Category findCR(@PathVariable("cid") int cid) 
	{
		return ps.findCR(cid);
	}
	
	@DeleteMapping("/deleteCR/{id}")
	public String deleteById1(@PathVariable("id") int cid) {
		ps.deleteById1(cid);
		return "category deleted successfully..!";
	}
	
	@PutMapping("/updateCR/{id}")
	public String updateCategory(@PathVariable("id") int cid, @RequestBody Category c1) {
		return ps.updateCategory(cid, c1);
	}
	
	
	
	
	
}
