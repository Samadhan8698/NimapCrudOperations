package com.data.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Product_info")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int pid;
	String pname;
	double price;
	
	@ManyToOne
	@JoinColumn(name="cid")
	
	@JsonBackReference
	Category cat ;

	public Product() {
		super();
	}

	public Product(int pid, String pname, double price, Category cat) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.cat = cat;
	}
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Category getCat() {
		return cat;
	}
	public void setCat(Category cat) {
		this.cat = cat;
	}
	
}
