package com.ask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryProductOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
